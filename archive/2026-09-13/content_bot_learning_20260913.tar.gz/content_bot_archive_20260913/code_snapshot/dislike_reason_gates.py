#!/usr/bin/env python3
"""Per-dislike-reason gates: menu / loot-run / no-gun / bad-render / boring."""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any


REASON_ALIASES: dict[str, str] = {
    "menu": "menu",
    "меню": "menu",
    "menu_lobby": "menu",
    "lobby": "menu",
    "menu_garage": "menu",
    "garage": "menu",
    "loot_run": "loot_run",
    "run": "loot_run",
    "running": "loot_run",
    "беготня": "loot_run",
    "explore": "loot_run",
    "no_gun": "no_gun",
    "no_shooting": "no_gun",
    "нет_стрельбы": "no_gun",
    "silent": "no_gun",
    "no_kill": "no_kill",
    "nokill": "no_kill",
    "нет_килла": "no_kill",
    "bad_render": "bad_render",
    "render": "bad_render",
    "blurry": "bad_render",
    "freeze": "bad_render",
    "boring": "boring",
    "скучно": "boring",
    "uninteresting": "boring",
}


@dataclass(frozen=True)
class ReasonThresholds:
    gun_density_min: float
    burst_ratio_min: float
    motion_max: float
    menu_overlay_max: float
    visual_min: float
    hook_gun_min: float
    hook_motion_min: float


# Separate floors per failure mode — never softens below BASE of game_adaptive_thresholds.
REASON_THRESHOLDS: dict[str, ReasonThresholds] = {
    "menu": ReasonThresholds(
        gun_density_min=0.085,
        burst_ratio_min=7.0,
        motion_max=0.14,
        menu_overlay_max=0.22,
        visual_min=0.35,
        hook_gun_min=0.04,
        hook_motion_min=0.04,
    ),
    "loot_run": ReasonThresholds(
        gun_density_min=0.090,
        burst_ratio_min=7.5,
        # Stricter locomotion ceiling so kill windows with long run-ups get cut/rejected.
        motion_max=0.08,
        menu_overlay_max=0.30,
        visual_min=0.32,
        hook_gun_min=0.05,
        hook_motion_min=0.035,
    ),
    "no_gun": ReasonThresholds(
        gun_density_min=0.095,
        burst_ratio_min=8.0,
        motion_max=0.20,
        menu_overlay_max=0.35,
        visual_min=0.30,
        hook_gun_min=0.06,
        hook_motion_min=0.02,
    ),
    # Owner 👎 no_kill: require kill evidence; keep combat floors high.
    "no_kill": ReasonThresholds(
        gun_density_min=0.055,
        burst_ratio_min=4.5,
        motion_max=0.18,
        menu_overlay_max=0.30,
        visual_min=0.30,
        hook_gun_min=0.04,
        hook_motion_min=0.03,
    ),
    "bad_render": ReasonThresholds(
        gun_density_min=0.070,
        burst_ratio_min=6.5,
        motion_max=0.18,
        menu_overlay_max=0.28,
        visual_min=0.45,
        hook_gun_min=0.03,
        hook_motion_min=0.03,
    ),
    "boring": ReasonThresholds(
        gun_density_min=0.080,
        burst_ratio_min=7.0,
        motion_max=0.16,
        menu_overlay_max=0.30,
        visual_min=0.40,
        hook_gun_min=0.045,
        hook_motion_min=0.035,
    ),
}


def normalize_reason(reason: str | None) -> str | None:
    if not reason:
        return None
    raw = str(reason).strip().lower().replace("-", "_").replace(" ", "_")
    if raw in REASON_ALIASES:
        return REASON_ALIASES[raw]
    for key, canon in REASON_ALIASES.items():
        if key in raw:
            return canon
    return None


def thresholds_for_reason(reason: str | None) -> ReasonThresholds | None:
    canon = normalize_reason(reason)
    if not canon:
        return None
    return REASON_THRESHOLDS.get(canon)


def _f(metrics: dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for key in keys:
        val = metrics.get(key)
        if isinstance(val, (int, float)):
            return float(val)
    return float(default)


def evaluate_reason_gates(
    metrics: dict[str, Any] | None,
    *,
    active_reasons: list[str] | None = None,
) -> tuple[bool, str, dict[str, Any]]:
    """
    Apply the strictest of the reason-specific floors.
    active_reasons: optional list of recent owner dislike reasons to emphasize.
    If empty, still applies a mild union of loot_run+no_gun when env asks.
    """
    metrics = dict(metrics or {})
    reasons = [normalize_reason(r) for r in (active_reasons or [])]
    reasons = [r for r in reasons if r]
    if not reasons and os.environ.get("DISLIKE_REASON_GATES_DEFAULT", "1") == "1":
        # Always keep anti-menu + anti-loot + anti-no_kill floors on for PUBG feeds.
        reasons = ["menu", "loot_run", "no_kill"]

    chosen = [REASON_THRESHOLDS[r] for r in reasons if r in REASON_THRESHOLDS]
    if not chosen:
        return True, "ok", {"active_reasons": reasons}

    gun_min = max(t.gun_density_min for t in chosen)
    burst_min = max(t.burst_ratio_min for t in chosen)
    motion_max = min(t.motion_max for t in chosen)
    menu_max = min(t.menu_overlay_max for t in chosen)
    visual_min = max(t.visual_min for t in chosen)
    # Drought may raise menu ceiling. Gun/burst soften must NOT undercut loot_run
    # / no_kill floors — that is how mid-spray loot kept shipping under soften=2.
    loot_floor_lock = (
        os.environ.get("PUBG_DISLIKE_LOOT_FLOOR_LOCK", "1") == "1"
        and bool({"loot_run", "no_gun", "no_kill"} & set(reasons))
    )
    menu_override = os.environ.get("DISLIKE_MENU_OVERLAY_MAX", "").strip()
    if menu_override:
        try:
            menu_max = max(menu_max, float(menu_override))
        except ValueError:
            pass
    gun_override = os.environ.get("DISLIKE_GUN_DENSITY_MIN", "").strip()
    if gun_override and not loot_floor_lock:
        try:
            # Take the looser (lower) floor under drought soften.
            gun_min = min(gun_min, float(gun_override))
        except ValueError:
            pass
    burst_override = os.environ.get("DISLIKE_BURST_RATIO_MIN", "").strip()
    if burst_override and not loot_floor_lock:
        try:
            burst_min = min(burst_min, float(burst_override))
        except ValueError:
            pass

    gun = _f(metrics, "gun_density", "gunfire_density", "gunshot_density")
    burst = _f(metrics, "burst_ratio", "gun_burst_ratio")
    motion = _f(metrics, "center_motion", "motion", "run_motion")
    menu = _f(metrics, "menu_overlay", "overlay_text", "center_text")
    visual = _f(metrics, "visual", "visual_score", "clip_score", default=1.0)

    report = {
        "active_reasons": reasons,
        "loot_floor_lock": loot_floor_lock,
        "floors": {
            "gun_density_min": gun_min,
            "burst_ratio_min": burst_min,
            "motion_max": motion_max,
            "menu_overlay_max": menu_max,
            "visual_min": visual_min,
        },
        "metrics": {
            "gun_density": gun,
            "burst_ratio": burst,
            "motion": motion,
            "menu_overlay": menu,
            "visual": visual,
        },
    }
    combat_ok = False
    try:
        from pubg_fight_act_profile import is_combat_act

        combat_ok = is_combat_act(gun, burst)
        # Silent DSP false-gun must not unlock combat-act rescues (DGso_775).
        rms_now = _f(metrics, "audio_rms", "rms")
        audible_min = float(os.environ.get("PUBG_OWNER_FIGHT_MIN_RMS", "0.020"))
        if combat_ok and rms_now < audible_min:
            combat_ok = False
            report["silent_combat_act_blocked"] = True
    except Exception:
        combat_ok = False
    # Combat-act rescue may soften menu-only floors. Never lower loot_run /
    # no_gun / no_kill floors — owner 👎 (vhTD mid-burst, UkXwq loot) came from that.
    if combat_ok and os.environ.get("PUBG_DISLIKE_COMBAT_ACT_RESCUE", "1") == "1":
        locked = {"loot_run", "no_gun", "no_kill"} & set(reasons)
        # Labeled fight-candidate already cleared loot/bot/menu quality gates without
        # claiming a kill. Recent 👎 no_kill must not re-raise gun floors and starve
        # OCR-blind Metro acts the owner is rating (zRQC@2141 → 👍 after direct send).
        if (
            locked == {"no_kill"}
            and metrics.get("fight_candidate_owner_review")
            and os.environ.get("PUBG_FIGHT_CANDIDATE_DISLIKE_RESCUE", "1") == "1"
        ):
            locked = set()
            report["fight_candidate_dislike_rescue"] = True
        # Owner already 👍'd this neighborhood — don't starve it with global
        # dislike gun floors that were raised by unrelated 👎 no_kill clips.
        if (
            locked
            and metrics.get("near_owner_good")
            and combat_ok
            and os.environ.get("PUBG_OWNER_GOOD_DISLIKE_RESCUE", "1") == "1"
        ):
            locked = locked - {"no_kill"}
            report["owner_good_dislike_rescue"] = True
        if locked:
            report["combat_act_rescue_blocked_by"] = sorted(locked)
        else:
            report["combat_act_rescue"] = True
            try:
                from pubg_fight_act_profile import ACT_MIN_BURST, ACT_MIN_GUN

                gun_min = min(gun_min, float(ACT_MIN_GUN))
                burst_min = min(burst_min, float(ACT_MIN_BURST))
                report["floors"]["gun_density_min"] = gun_min
                report["floors"]["burst_ratio_min"] = burst_min
            except Exception:
                pass

    # Loot without running: weak gun + tiny PANNs/RMS, no kill (DGso_775).
    if "loot_run" in reasons and os.environ.get("PUBG_DISLIKE_LOOT_LOW_GUN_GATE", "1") == "1":
        panns = _f(metrics, "panns_gun_max", "panns_gun")
        rms_loot = _f(metrics, "audio_rms", "rms")
        low_gun = float(os.environ.get("PUBG_DISLIKE_LOOT_LOW_GUN", "0.050"))
        low_panns = float(os.environ.get("PUBG_DISLIKE_LOOT_LOW_PANNS", "0.12"))
        audible_min = float(os.environ.get("PUBG_OWNER_FIGHT_MIN_RMS", "0.020"))
        has_kill = bool(
            metrics.get("has_author_kill")
            or metrics.get("kill_notification_hit")
            or metrics.get("killfeed_hits")
            or metrics.get("keyword_hit")
        )
        if (
            gun > 0
            and gun <= low_gun
            and (panns <= low_panns or rms_loot < audible_min)
            and not has_kill
        ):
            return (
                False,
                f"reason_loot_low_gun=gun{gun:.3f}:panns{panns:.3f}:rms{rms_loot:.4f}",
                report,
            )

    if menu >= menu_max and menu > 0:
        # ADS/HUD/PiP often inflate center-text into "menu" while audio is a real
        # Metro fight. Combat-act audio rescues those.
        if combat_ok and os.environ.get("PUBG_DISLIKE_COMBAT_ACT_MENU_RESCUE", "1") == "1":
            report["combat_act_menu_rescue"] = True
        else:
            return False, f"reason_menu_overlay={menu:.3f}>={menu_max:.3f}", report
    if gun > 0 and gun < gun_min:
        return False, f"reason_low_gun={gun:.3f}<{gun_min:.3f}", report
    if burst > 0 and burst < burst_min:
        return False, f"reason_low_burst={burst:.2f}<{burst_min:.2f}", report
    # Loot/run: high locomotion with non-dominant gun — even when gun clears floor.
    if (
        "loot_run" in reasons
        and motion > motion_max
        and gun < max(gun_min, float(os.environ.get("PUBG_DISLIKE_LOOT_STRONG_GUN", "0.085")))
    ):
        # Drought soften + combat-act: short fight snaps often have motion>gun while
        # audio is a real Metro spray (OCR-blind). Allow rescue so force-send can
        # ship fight-cluster clips instead of dying on reason_loot_run after render.
        rms = _f(metrics, "audio_rms", "rms")
        rms_min = float(os.environ.get("PUBG_DISLIKE_COMBAT_ACT_LOOT_RESCUE_MIN_RMS", "0.025"))
        if (
            combat_ok
            and os.environ.get("PUBG_DISLIKE_COMBAT_ACT_LOOT_RESCUE", "0") == "1"
            and rms >= rms_min
        ):
            report["combat_act_loot_run_rescue"] = True
            report["combat_act_loot_run_rescue_rms"] = rms
        else:
            return False, f"reason_loot_run=motion{motion:.3f}>gun{gun:.3f}", report
    if motion > 0 and gun < gun_min * 0.85 and motion > motion_max:
        rms = _f(metrics, "audio_rms", "rms")
        rms_min = float(os.environ.get("PUBG_DISLIKE_COMBAT_ACT_LOOT_RESCUE_MIN_RMS", "0.025"))
        if (
            combat_ok
            and os.environ.get("PUBG_DISLIKE_COMBAT_ACT_LOOT_RESCUE", "0") == "1"
            and rms >= rms_min
        ):
            report["combat_act_loot_run_rescue"] = True
            report["combat_act_loot_run_rescue_rms"] = rms
        else:
            return False, f"reason_loot_run=motion{motion:.3f}>gun{gun:.3f}", report
    if visual < visual_min:
        return False, f"reason_low_visual={visual:.3f}<{visual_min:.3f}", report
    if "no_kill" in reasons and os.environ.get("PUBG_DISLIKE_REQUIRE_KILL_EVIDENCE", "1") == "1":
        has_kill = bool(
            metrics.get("has_author_kill")
            or metrics.get("kill_notification_hit")
            or metrics.get("killfeed_hits")
            or metrics.get("keyword_hit")
        )
        killfeed = _f(metrics, "killfeed_density", "effective_killfeed")
        notif = _f(metrics, "kill_notification_score", "notification_score")
        notif_min = float(os.environ.get("PUBG_KILL_NOTIFICATION_MIN_SCORE", "0.50"))
        report["kill_evidence"] = {
            "has_author_kill": bool(metrics.get("has_author_kill")),
            "kill_notification_hit": bool(metrics.get("kill_notification_hit")),
            "killfeed_density": killfeed,
            "kill_notification_score": notif,
        }
        if not has_kill and killfeed < 0.30 and notif < notif_min:
            if (
                metrics.get("fight_candidate_owner_review")
                and os.environ.get("PUBG_FIGHT_CANDIDATE_DISLIKE_RESCUE", "1") == "1"
            ):
                report["fight_candidate_no_kill_evidence_waive"] = True
            else:
                return False, "reason_no_kill_evidence", report
    return True, "ok", report


def recent_dislike_reasons(game: str, *, limit: int = 30) -> list[str]:
    """Pull recent bad-feedback reasons from the quality ledger."""
    try:
        from vod_clip_quality_ledger import iter_events
    except Exception:
        return []
    out: list[str] = []
    for row in reversed(iter_events(game)):
        if row.get("decision") != "feedback" or row.get("label") != "bad":
            continue
        canon = normalize_reason(str(row.get("reason") or ""))
        if canon:
            out.append(canon)
        if len(out) >= limit:
            break
    return out
