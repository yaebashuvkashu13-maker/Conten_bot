#!/usr/bin/env python3
"""Owner-labeled PUBG Metro windows for gate tuning and segment ranking."""

from __future__ import annotations

import json
import os
from pathlib import Path

LABELS_PATH = Path(
    os.environ.get("PUBG_OWNER_LABELS_PATH", "/root/data/pubg/pubg_owner_labels.json")
)
# Legacy path kept as a merge source (older deploys wrote under mlbb/).
LEGACY_LABELS_PATH = Path("/root/data/mlbb/pubg_owner_labels.json")
REPO_LABELS_PATH = Path(__file__).resolve().parent.parent / "data" / "pubg_owner_labels.json"

# n97cHIR9Qow — owner review 2026-06-06
DEFAULT_LABELS: dict[str, list[dict]] = {
    "n97cHIR9Qow": [
        {"tc": "30:45", "time_sec": 1845.0, "label": "good"},
        {"tc": "33:25", "time_sec": 2005.0, "label": "good"},
        {"tc": "35:05", "time_sec": 2105.0, "label": "bad"},
        {"tc": "35:50", "time_sec": 2150.0, "label": "good"},
        {"tc": "36:55", "time_sec": 2215.0, "label": "bad"},
        {"tc": "38:07", "time_sec": 2287.0, "label": "bad"},
        {"tc": "41:10", "time_sec": 2470.0, "label": "good"},
        {"tc": "42:01", "time_sec": 2521.0, "label": "bad"},
    ],
}


def _read_labels_file(path: Path) -> dict:
    """Load per-video rows. Also fold top-level `labels` (TG feedback appends)."""
    from path_safe import exists as path_exists

    if not path_exists(path):
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(payload, dict):
        return {}
    videos: dict[str, list[dict]] = {}
    raw_videos = payload.get("videos")
    if isinstance(raw_videos, dict):
        for vid, rows in raw_videos.items():
            if isinstance(rows, list):
                videos[str(vid)] = [r for r in rows if isinstance(r, dict)]
    # Flat feedback rows (owner_tg_feedback) must feed the same map gates read.
    flat = payload.get("labels")
    if isinstance(flat, list):
        for row in flat:
            if not isinstance(row, dict):
                continue
            vid = str(row.get("video_id") or row.get("vid") or "").strip()
            if not vid:
                vod = str(row.get("vod") or "")
                stem = Path(vod).stem
                if stem.startswith("yt_") and len(stem) > 3:
                    vid = stem[3:]
            if not vid:
                continue
            entry = dict(row)
            if "time_sec" not in entry and entry.get("t") is not None:
                try:
                    entry["time_sec"] = float(entry["t"])
                except (TypeError, ValueError):
                    continue
            videos.setdefault(vid, []).append(entry)
    if videos:
        return videos
    # Legacy: whole file is {video_id: [rows]}
    if "videos" not in payload and "labels" not in payload:
        return {
            str(k): [r for r in v if isinstance(r, dict)]
            for k, v in payload.items()
            if isinstance(v, list)
        }
    return {}


def load_owner_labels() -> dict[str, list[dict]]:
    merged = {vid: list(rows) for vid, rows in DEFAULT_LABELS.items()}
    for path in (LABELS_PATH, LEGACY_LABELS_PATH, REPO_LABELS_PATH):
        for vid, rows in _read_labels_file(path).items():
            merged.setdefault(vid, [])
            seen = {(r.get("time_sec"), r.get("label")) for r in merged[vid]}
            for row in rows:
                key = (row.get("time_sec"), row.get("label"))
                if key not in seen:
                    merged[vid].append(row)
                    seen.add(key)
    return merged


def video_id_from_path(video_path: Path) -> str | None:
    stem = video_path.stem
    if stem.startswith("yt_") and len(stem) > 3:
        return stem[3:]
    return None


def labels_for_video(video_path: Path) -> list[dict]:
    vid = video_id_from_path(video_path)
    if not vid:
        return []
    return load_owner_labels().get(vid, [])


def nearest_owner_label(
    video_path: Path,
    start_sec: float,
    *,
    radius_sec: float = 14.0,
) -> tuple[str | None, float]:
    """Return ('good'|'bad'|None, distance_sec) for the closest owner label."""
    labels = labels_for_video(video_path)
    if not labels:
        return None, 999.0
    best_label: str | None = None
    best_dist = 999.0
    for row in labels:
        dist = abs(float(row["time_sec"]) - start_sec)
        if dist <= radius_sec and dist < best_dist:
            best_dist = dist
            best_label = str(row["label"])
    return best_label, best_dist


def segment_overlaps_owner_label(
    video_path: Path,
    start_sec: float,
    duration_sec: float,
    *,
    label: str,
    pad_sec: float | None = None,
) -> bool:
    end_sec = start_sec + duration_sec
    for row in labels_for_video(video_path):
        if row.get("label") != label:
            continue
        center = float(row["time_sec"])
        note = str(row.get("note") or row.get("reason") or "")
        pad = float(pad_sec) if pad_sec is not None else owner_bad_pad_sec(note if label == "bad" else "")
        if label == "good" and pad_sec is None:
            pad = float(os.environ.get("PUBG_OWNER_GOOD_PAD_SEC", "10"))
        if start_sec - pad <= center <= end_sec + pad:
            return True
    return False


def owner_bad_pad_sec(note: str = "") -> float:
    """Block radius around owner 👎 — wider for run/empty/loot notes from label bank."""
    base = float(os.environ.get("PUBG_OWNER_BAD_PAD_SEC", "12"))
    text = note.strip().lower()
    if any(
        token in text
        for token in (
            "run",
            "empty",
            "loot",
            "walk",
            "fly",
            "no fight",
            "no_combat",
            "loot_run",
            "no_kill",
            "no_combat",
        )
    ):
        return max(base, float(os.environ.get("PUBG_OWNER_BAD_RUN_PAD_SEC", "30")))
    return base


def has_owner_labels(video_path: Path) -> bool:
    return bool(labels_for_video(video_path))


def apply_owner_send_policy() -> None:
    """Apply owner-label-bank send criteria to the current process.

    Send only clips where the streamer is actually shooting (gun+burst), not run/loot/fly.
    Ground truth: data/pubg_owner_labels.json and runtime Telegram 👍/👎 labels.
    Global fight-act floors (owner 6mWLqNBX1pE) apply to every VOD — no per-video labeling.
    """
    try:
        from pubg_fight_act_profile import apply_global_act_defaults

        apply_global_act_defaults()
    except ImportError:
        pass
    os.environ.setdefault("PUBG_PRESEND_SHOOTING_GATE", "1")
    os.environ.setdefault("PUBG_AUTHOR_KILL_ALLOW_FLASH", "0")
    os.environ.setdefault("PUBG_BOT_FARM_KILLFEED_WAIVE", "0")
    os.environ.setdefault("PUBG_QUALITY_BOT_FARM_GATE", "1")
    os.environ.setdefault("PUBG_PRESEND_SCORE_MODE", "1")
    os.environ.setdefault("PUBG_REJECT_LOOT_WALK", "1")
    if os.environ.get("VOD_FORCE_SOFTEN", "0") != "1":
        os.environ.setdefault("PUBG_FAST_RANK_DROP_LOOT_WALK", "1")
    # Singles: keep early OCR payoff soft, but require author-kill evidence —
    # owner 👎 no_kill / loot_run were shipping via combat-act bypass.
    os.environ.setdefault("PUBG_EARLY_PAYOFF_REJECT_SINGLES", "0")
    os.environ.setdefault("PUBG_REQUIRE_AUTHOR_KILL_SINGLES", "1")
    os.environ.setdefault("PUBG_COMBAT_ACT_ALLOW_NO_KILL", "0")
    os.environ.setdefault("PUBG_OWNER_GOOD_TRUST_NO_KILL", "0")
    # Under drought soften, do NOT re-lock dislike gun floors — that undoes
    # apply_drought_pubg_env and recreates reason_low_gun silence.
    drought_soft = os.environ.get("VOD_FORCE_SOFTEN", "0") == "1"
    try:
        drought_soft = drought_soft or int(os.environ.get("VOD_FORCE_ESCALATION", "0") or 0) > 0
    except ValueError:
        pass
    if drought_soft:
        os.environ["PUBG_DISLIKE_LOOT_FLOOR_LOCK"] = "0"
        os.environ["PUBG_FAST_RANK_DROP_LOOT_WALK"] = os.environ.get(
            "PUBG_FAST_RANK_DROP_LOOT_WALK", "0"
        )
    else:
        os.environ.setdefault("PUBG_DISLIKE_LOOT_FLOOR_LOCK", "1")
    os.environ.setdefault("PUBG_DISLIKE_REQUIRE_KILL_EVIDENCE", "1")
    os.environ.setdefault("PUBG_PAYOFF_SCORE_MIN_SINGLES", "0.10")
    os.environ.setdefault("PUBG_QUALITY_SCORE_MIN_SINGLES", "0.28")
    os.environ.setdefault("PUBG_SINGLES_GUN_PAYOFF_BYPASS", "0")
    os.environ.setdefault("PUBG_SINGLES_GUN_QUALITY_BYPASS", "0")
    os.environ.setdefault("PUBG_SINGLE_MIN_GUN_DENSITY", "0.032")
    os.environ.setdefault("PUBG_CLIP_MIN_BURST_RATIO", "4.5")
    os.environ.setdefault("SHOOTER_VOD_MONTAGE_SHOOTING_ONLY", "0")
    os.environ.setdefault("SHOOTER_REQUIRE_AUTHOR_KILL", "0")
    os.environ.setdefault("PUBG_OWNER_BAD_PAD_SEC", "12")
    os.environ.setdefault("PUBG_OWNER_BAD_RUN_PAD_SEC", "30")
    os.environ.setdefault("PUBG_AUTHOR_KILL_STYLE_COMBAT", "1")
    os.environ.setdefault("SHOOTER_VOD_MAX_SOFTEN_LEVEL", "2")
    os.environ.setdefault("SHOOTER_VOD_ZERO_STREAK_SOFTEN", "1")
    os.environ.setdefault("PUBG_DROUGHT_ELASTICITY", "1")
    os.environ.setdefault("PUBG_DROUGHT_ELASTICITY_IDLE_RATE", "0.15")
    os.environ.setdefault("PUBG_DROUGHT_ELASTICITY_FLOOR", "0.70")
    os.environ.setdefault("PUBG_DROUGHT_ELASTICITY_POST_SEND", "1.10")

    os.environ.setdefault("PUBG_STYLE_COMBAT_MIN_GUN", "0.032")
    os.environ.setdefault("PUBG_STYLE_COMBAT_MIN_BURST", "4.5")
    os.environ.setdefault("PUBG_STYLE_COMBAT_MIN_PANNS", "0.28")
    os.environ.setdefault("PUBG_STYLE_COMBAT_MIN_FLASH", "0.020")
    os.environ.setdefault("PUBG_STYLE_FAKE_GUN_OVERRIDE_MIN_GUN", "0.028")
    os.environ.setdefault("PUBG_STYLE_FAKE_GUN_OVERRIDE_MIN_PANNS", "0.38")


def pubg_passes_tiktok_combat_gate(
    video_path: Path,
    start_sec: float,
    gunfire_density: float,
    burst_ratio: float,
    *,
    center_motion: float = 0.0,
) -> tuple[bool, str]:
    """TikTok: visible brawl — anchor to owner-good fights, never talk/sniper-only."""
    anchor_only = os.environ.get("SMART_PUBG_ANCHOR_GOOD_ONLY", "0") == "1"
    owner_near, owner_dist = nearest_owner_label(video_path, start_sec, radius_sec=12.0)

    if has_owner_labels(video_path):
        if owner_near != "good" or owner_dist > 9.0:
            return False, f"tiktok_off_anchor=dist{owner_dist:.0f}"
        min_gun = 0.048 if owner_dist <= 4.0 else 0.056
        min_burst = 4.6 if owner_dist <= 4.0 else 5.6
        if gunfire_density >= min_gun and burst_ratio >= min_burst:
            if gunfire_density < 0.052 and center_motion < 0.030:
                return False, f"tiktok_sniper_only=gun{gunfire_density:.3f}:motion{center_motion:.3f}"
            return True, f"tiktok_anchor_fight=dist{owner_dist:.0f}:gun{gunfire_density:.3f}"
        return False, f"tiktok_anchor_weak=gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"

    if anchor_only:
        return False, "tiktok_no_owner_labels"
    if gunfire_density >= 0.090 and burst_ratio >= 6.0 and center_motion >= 0.035:
        return True, "tiktok_hot_audio"
    return False, f"tiktok_no_brawl=gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"


def pubg_passes_owner_heuristics(
    gunfire_density: float,
    burst_ratio: float,
    audio_rms: float,
    center_motion: float,
    *,
    panns_gun_max: float = 0.0,
) -> tuple[bool, str]:
    """Rules fitted to owner labels on n97cHIR9Qow (2026-06-06)."""
    panns_trust = float(os.environ.get("PUBG_PANNS_TRUST_MIN", "0.35"))
    min_gun_panns = float(os.environ.get("PUBG_PANNS_TRUST_MIN_GUN", "0.040"))
    min_burst_panns = float(os.environ.get("PUBG_PANNS_TRUST_MIN_BURST", "3.0"))
    # Owner-calibrated Metro acts (6mWLqNBX1pE): gun 0.03–0.09 with burst≥5 is a
    # real fight, even while strafing. High burst escapes fake-gun motion traps.
    burst_escape = float(os.environ.get("PUBG_FAKE_GUN_BURST_ESCAPE", "5.5"))
    burst_escape_gun = float(os.environ.get("PUBG_FAKE_GUN_BURST_ESCAPE_GUN", "0.028"))

    def _burst_says_real_gun() -> bool:
        return burst_ratio >= burst_escape and gunfire_density >= burst_escape_gun

    # Global fight-act profile (owner 6mWLqNBX1pE principle): mid gun + mid
    # burst is a real act on EVERY VOD — do not wait for labels.
    # Still require audible RMS: silent DSP false-gun (DGso 257/1026, rms~0.008)
    # previously returned combat_act=True and shipped loot_run / empty clips.
    audible_min = float(os.environ.get("PUBG_OWNER_FIGHT_MIN_RMS", "0.020"))
    try:
        from pubg_fight_act_profile import is_combat_act

        if is_combat_act(gunfire_density, burst_ratio):
            if audio_rms >= audible_min:
                return True, f"combat_act=gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"
            return (
                False,
                f"silent_fake_gun=rms{audio_rms:.4f}:gun{gunfire_density:.3f}",
            )
    except ImportError:
        pass

    if panns_gun_max >= panns_trust:
        # High PANNs on loot/UI SFX must not bless a run with weak DSP gun
        # (_-HbZ0zNDOs_2538: panns_machine_gun=0.74 while looting crates, gun~0.056).
        # Real ADS fights often sit at gun 0.06–0.10 with aim sway (motion≥0.075)
        # and strong PANNs — the old gun<0.115 ceiling falsely rejected those.
        fake_gun_ceil = float(os.environ.get("PUBG_PANNS_FAKE_GUN_MAX", "0.075"))
        if (
            center_motion >= 0.075
            and gunfire_density < fake_gun_ceil
            and not _burst_says_real_gun()
        ):
            return (
                False,
                f"run_fake_gun=motion{center_motion:.3f}:gun{gunfire_density:.3f}",
            )
        if center_motion > 0.22 and gunfire_density < 0.052 and not _burst_says_real_gun():
            return (
                False,
                f"run_loot=motion{center_motion:.3f}:gun{gunfire_density:.3f}",
            )
        if gunfire_density >= min_gun_panns and (
            burst_ratio >= min_burst_panns or gunfire_density >= 0.055
        ):
            return True, f"panns_trust={panns_gun_max:.3f}"
        if _burst_says_real_gun():
            return True, f"burst_act=gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"
        return False, f"panns_no_gun=pan{panns_gun_max:.3f}:gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"
    relax = os.environ.get("PUBG_RELAX_OWNER_HEURISTICS", "0")
    if relax in ("1", "2"):
        if panns_gun_max >= max(0.22, panns_trust - 0.08) and gunfire_density >= 0.020:
            return True, f"panns_audio=pan{panns_gun_max:.3f}:gun{gunfire_density:.3f}"
        if gunfire_density >= 0.040 and burst_ratio >= 3.5:
            return True, f"relax_fight=gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"
        if gunfire_density >= 0.055:
            return True, "relax_fight_audio"
        if relax == "2" and panns_gun_max >= 0.20:
            return True, f"panns_relax_l4={panns_gun_max:.3f}"
    if audio_rms > 0.050 and gunfire_density < 0.015 and panns_gun_max < 0.25:
        return False, f"talk_menu=rms{audio_rms:.4f}:gun{gunfire_density:.3f}"
    if center_motion > 0.22 and gunfire_density < 0.052 and panns_gun_max < 0.30:
        if not _burst_says_real_gun():
            return False, f"run_loot=motion{center_motion:.3f}:gun{gunfire_density:.3f}"
    if center_motion >= 0.075 and gunfire_density < 0.115 and panns_gun_max < 0.28:
        if not _burst_says_real_gun():
            return False, f"run_fake_gun=motion{center_motion:.3f}:gun{gunfire_density:.3f}"
    if gunfire_density < 0.040 and audio_rms > 0.036 and not _burst_says_real_gun():
        return False, f"talk_low_gun=rms{audio_rms:.4f}:gun{gunfire_density:.3f}"
    # Silent false-gun (DGso 660/257/1026): DSP gun/burst can fire while RMS≈0
    # and the frame is just running. Require audible floor for fight-audio paths.
    audible_min = float(os.environ.get("PUBG_OWNER_FIGHT_MIN_RMS", "0.020"))
    if audio_rms < audible_min and gunfire_density < 0.10:
        return (
            False,
            f"silent_fake_gun=rms{audio_rms:.4f}:gun{gunfire_density:.3f}",
        )
    if gunfire_density >= 0.055 and audio_rms >= audible_min:
        return True, "fight_audio"
    if _burst_says_real_gun() and audio_rms >= audible_min:
        return True, f"burst_act=gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"
    if center_motion < 0.022 and gunfire_density >= 0.028 and burst_ratio >= 5.5:
        return True, "sniper_hold"
    # Was: gun>=0.048 + burst>=4.8 + rms<0.040 → "light_combat". That shipped
    # silent loot_run as fights. Require audible RMS instead.
    if gunfire_density >= 0.048 and burst_ratio >= 4.8 and audio_rms >= audible_min:
        return True, "light_combat"
    # Mid-band Metro sprays (owner acts often burst 3.5–4.5 with gun≥0.032).
    if gunfire_density >= 0.032 and burst_ratio >= 3.5 and audio_rms >= audible_min:
        return True, f"metro_act=gun{gunfire_density:.3f}:burst{burst_ratio:.2f}"
    return False, f"below_owner_floor=density{gunfire_density:.3f}:burst{burst_ratio:.2f}"
