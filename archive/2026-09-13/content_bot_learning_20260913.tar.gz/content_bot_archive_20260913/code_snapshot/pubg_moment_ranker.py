#!/usr/bin/env python3
"""Train and apply a PUBG moment ranker from owner timestamps and part feedback."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any

FEATURE_VERSION = 2
FEATURE_NAMES = (
    "panns_gunshot",
    "panns_machine_gun",
    "panns_explosion",
    "panns_speech",
    "panns_music",
    "panns_gun_max",
    "gunfire_density",
    "burst_ratio",
    "audio_rms",
)
_MODEL_CACHE: tuple[str, int, dict] | None = None


def _repo_root() -> Path:
    return Path(os.environ.get("CONTENT_BOT_REPO", Path(__file__).resolve().parent.parent))


def model_path() -> Path:
    champion = os.environ.get("PUBG_RANKER_CHAMPION_PATH", "").strip()
    if champion:
        return Path(champion)
    from path_safe import is_file as path_is_file

    default_champion = Path("/root/data/pubg/ranker_models/champion.joblib")
    if path_is_file(default_champion):
        return default_champion
    return Path(
        os.environ.get(
            "PUBG_RANKER_MODEL",
            "/root/data/pubg/pubg_moment_ranker.joblib",
        )
    )


def feature_cache_root() -> Path:
    return Path(
        os.environ.get(
            "PUBG_RANKER_FEATURE_CACHE",
            "/root/data/pubg/ranker_features",
        )
    )


def owner_labels_path() -> Path:
    if os.environ.get("VOD_RUNTIME_LABELS", "1") == "1":
        from runtime_labels import ensure_runtime_labels

        path = ensure_runtime_labels("pubg")
        if path is not None:
            return path
    override = os.environ.get("PUBG_OWNER_LABELS_PATH", "").strip()
    if override:
        return Path(override)
    from path_safe import exists as path_exists

    for path in (
        _repo_root() / "data" / "pubg_owner_labels.json",
        Path("/root/data/mlbb/pubg_owner_labels.json"),
    ):
        if path_exists(path):
            return path
    return _repo_root() / "data" / "pubg_owner_labels.json"


def feedback_path() -> Path:
    return Path(
        os.environ.get(
            "PUBG_SEGMENT_LABELS_PATH",
            "/root/data/pubg/vod_segment_labels.json",
        )
    )


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def resolve_vod(video_id: str, *, hinted_path: str = "") -> Path | None:
    from path_safe import is_file as path_is_file

    hinted = Path(hinted_path) if hinted_path else None
    candidates: list[Path] = []
    if hinted is not None:
        candidates.append(hinted)
    pubg_root = Path(os.environ.get("SHOOTER_PUBG_DATA_ROOT", "/root/data/pubg"))
    candidates.extend(
        [
            pubg_root / "youtube_nightly" / "inbox" / f"yt_{video_id}.mp4",
            pubg_root / "youtube_nightly" / "parked" / f"yt_{video_id}.mp4",
            pubg_root / "youtube_nightly" / "park_timeout" / f"yt_{video_id}.mp4",
            pubg_root / "regression_vods" / f"yt_{video_id}.mp4",
            _repo_root() / "data" / "samples" / f"yt_{video_id}.mp4",
        ]
    )
    for path in candidates:
        if path_is_file(path):
            return path
    return None


def _video_id(path: Path) -> str:
    stem = path.stem
    return stem[3:14] if stem.startswith("yt_") else stem[:11]


def _feature_key(video_path: Path, start_sec: float, duration_sec: float) -> str:
    stat = video_path.stat()
    raw = (
        f"v{FEATURE_VERSION}|{video_path.resolve()}|{stat.st_size}|{stat.st_mtime_ns}|"
        f"{start_sec:.2f}|{duration_sec:.2f}"
    )
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def extract_features(video_path: Path, start_sec: float, duration_sec: float = 14.0) -> dict[str, float]:
    """Extract inference-safe features; cache makes train/re-rank repeatable."""
    key = _feature_key(video_path, start_sec, duration_sec)
    cache_file = feature_cache_root() / f"{key}.json"
    cached = _read_json(cache_file)
    if cached.get("version") == FEATURE_VERSION and isinstance(cached.get("features"), dict):
        return {name: float(cached["features"].get(name, 0.0)) for name in FEATURE_NAMES}

    from highlight_scorer import score_panns_audio
    from gameplay_gate import score_pubg_gunfire_audio

    panns = score_panns_audio(video_path, start_sec, duration_sec)
    gun, burst, rms = score_pubg_gunfire_audio(video_path, start_sec, duration_sec)
    features = {
        "panns_gunshot": float(panns.get("panns_gunshot", 0.0)),
        "panns_machine_gun": float(panns.get("panns_machine_gun", 0.0)),
        "panns_explosion": float(panns.get("panns_explosion", 0.0)),
        "panns_speech": float(panns.get("panns_speech", 0.0)),
        "panns_music": float(panns.get("panns_music", 0.0)),
        "panns_gun_max": float(panns.get("panns_gun_max", 0.0)),
        "gunfire_density": float(gun),
        "burst_ratio": float(burst),
        "audio_rms": float(rms),
    }
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": FEATURE_VERSION, "saved_at": time.time(), "features": features}
    tmp = cache_file.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, cache_file)
    return features


def feature_vector(features: dict[str, float]) -> list[float]:
    return [float(features.get(name, 0.0)) for name in FEATURE_NAMES]


@dataclass(frozen=True)
class TrainingSample:
    video_id: str
    video_path: Path
    peak_sec: float
    label: int
    source: str
    weight: float
    features: dict[str, float] | None = None


def features_from_quality_report(report: dict) -> dict[str, float] | None:
    if not isinstance(report, dict):
        return None
    features = {
        name: float(report.get(name, 0.0) or 0.0)
        for name in FEATURE_NAMES
    }
    if not any(features.values()):
        return None
    return features


def load_training_samples() -> list[TrainingSample]:
    """Owner labels first; newer per-part feedback overrides the same moment."""
    samples: dict[tuple[str, int], TrainingSample] = {}
    owner_augment = max(0.0, float(os.environ.get("PUBG_RANKER_OWNER_AUGMENT_SEC", "20")))
    feedback_augment = max(
        0.0,
        float(os.environ.get("PUBG_RANKER_FEEDBACK_AUGMENT_SEC", "10")),
    )

    from pubg_label_reason import normalize_reason, weight_multiplier

    def add(
        video_id: str,
        vod: Path,
        peak: float,
        label: int,
        source: str,
        weight: float,
        features: dict[str, float] | None = None,
        *,
        augment: float = 0.0,
        reason: str = "",
    ) -> None:
        reason_code = normalize_reason(reason)
        weight = float(weight) * weight_multiplier(reason_code, label=int(label))
        offsets = (0.0,) if augment <= 0 else (-augment, 0.0, augment)
        for offset in offsets:
            sample_peak = max(0.0, peak + offset)
            sample_weight = weight if offset == 0 else weight * 0.60
            samples[(video_id, round(sample_peak))] = TrainingSample(
                video_id,
                vod,
                sample_peak,
                label,
                source if offset == 0 else f"{source}_jitter",
                sample_weight,
                features if offset == 0 else None,
            )

    owner = _read_json(owner_labels_path())
    for video_id, rows in (owner.get("videos") or {}).items():
        vod = resolve_vod(str(video_id))
        if not vod or not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict) or "time_sec" not in row:
                continue
            label = 1 if row.get("label") == "good" else 0
            peak = float(row["time_sec"])
            note = str(row.get("note") or row.get("reason") or "")
            add(
                str(video_id),
                vod,
                peak,
                label,
                "owner_label",
                2.0,
                augment=owner_augment,
                reason=note,
            )

    feedback = _read_json(feedback_path())
    for bucket, label in (("good", 1), ("bad", 0)):
        for row in feedback.get(bucket) or []:
            if not isinstance(row, dict):
                continue
            sid = str(row.get("segment_id") or "")
            video_id = str(row.get("vod_id") or "")
            if not video_id and sid:
                try:
                    from vod_owner_learning import parse_pubg_segment_sid

                    parsed = parse_pubg_segment_sid(sid)
                    if parsed:
                        video_id = parsed[0]
                except Exception:
                    if "_" in sid:
                        video_id = sid.rsplit("_", 1)[0]
            hinted = str(row.get("vod") or "")
            vod = resolve_vod(video_id, hinted_path=hinted)
            if not video_id or not vod:
                continue
            peak = float(row.get("peak_start", row.get("start", 0)) or 0)
            reason = str(row.get("reason") or row.get("note") or "")
            add(
                video_id,
                vod,
                peak,
                label,
                "part_feedback",
                1.0,
                features_from_quality_report(row.get("quality_metrics") or {}),
                augment=feedback_augment,
                reason=reason,
            )

    # Explicit 15s window ratings (learnable-loop unit).
    try:
        from pubg_ranker_dataset import load_window_label_rows, window_labels_path

        if window_labels_path().is_file():
            for row in load_window_label_rows():
                video_id = str(row["video_id"])
                hinted = str(row.get("video_path") or "")
                vod = resolve_vod(video_id, hinted_path=hinted)
                if not vod:
                    continue
                feats = row.get("features") if isinstance(row.get("features"), dict) else None
                add(
                    video_id,
                    vod,
                    float(row["peak_sec"]),
                    int(row["label"]),
                    str(row.get("source") or "window_label"),
                    float(row.get("weight") or 1.5),
                    feats,
                    augment=0.0,
                    reason=str(row.get("event") or row.get("reason") or ""),
                )
    except Exception:
        pass
    return sorted(samples.values(), key=lambda row: (row.video_id, row.peak_sec))


def training_signature() -> str:
    digest = hashlib.sha256()
    paths = [owner_labels_path(), feedback_path()]
    try:
        from pubg_ranker_dataset import window_labels_path

        paths.append(window_labels_path())
    except Exception:
        pass
    for path in paths:
        digest.update(str(path).encode())
        try:
            digest.update(path.read_bytes())
        except OSError:
            pass
    digest.update(str(FEATURE_VERSION).encode())
    return digest.hexdigest()


def _threshold_metrics(
    y_true: list[int],
    probabilities: list[float],
    threshold: float,
) -> tuple[float, float, float]:
    pred = [int(p >= threshold) for p in probabilities]
    tp = sum(1 for y, p in zip(y_true, pred) if y == p == 1)
    fp = sum(1 for y, p in zip(y_true, pred) if y == 0 and p == 1)
    tn = sum(1 for y, p in zip(y_true, pred) if y == p == 0)
    fn = sum(1 for y, p in zip(y_true, pred) if y == 1 and p == 0)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    specificity = tn / max(tn + fp, 1)
    balanced = (recall + specificity) * 0.5
    f1 = 2 * precision * recall / max(precision + recall, 1e-9)
    return balanced * 0.7 + f1 * 0.3, balanced, f1


def _best_threshold(y_true: list[int], probabilities: list[float]) -> tuple[float, float, float]:
    if not y_true or len(set(y_true)) < 2:
        return 0.5, 0.0, 0.0
    best = (0.0, 0.5, 0.0, 0.0)
    for threshold in [x / 100 for x in range(30, 76, 5)]:
        objective, balanced, f1 = _threshold_metrics(y_true, probabilities, threshold)
        if (objective, threshold) > (best[0], best[1]):
            best = (objective, threshold, balanced, f1)
    return best[1], best[2], best[3]


def train(*, if_changed: bool = False, dataset: Path | None = None) -> dict[str, Any]:
    global _MODEL_CACHE
    import joblib
    import numpy as np
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import LeaveOneGroupOut
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    output = model_path()
    if dataset is not None:
        from pubg_ranker_dataset import samples_from_dataset

        samples = samples_from_dataset(Path(dataset))
    else:
        samples = load_training_samples()
    sample_state = [
        (
            row.video_id,
            round(row.peak_sec, 2),
            row.label,
            row.source,
            round(float(row.weight), 3),
            row.video_path.stat().st_size,
            row.video_path.stat().st_mtime_ns,
        )
        for row in samples
    ]
    signature = hashlib.sha256(
        f"{training_signature()}|{sample_state}".encode()
    ).hexdigest()
    if if_changed and output.exists():
        try:
            old = joblib.load(output)
            if old.get("training_signature") == signature:
                return {"status": "unchanged", "path": str(output)}
        except Exception:
            pass

    positives = sum(row.label for row in samples)
    negatives = len(samples) - positives
    if len(samples) < 12 or positives < 4 or negatives < 4:
        return {
            "status": "insufficient_samples",
            "samples": len(samples),
            "positive": positives,
            "negative": negatives,
        }

    def sample_vector(row: TrainingSample) -> list[float]:
        return feature_vector(
            row.features
            or extract_features(row.video_path, max(0.0, row.peak_sec - 7.0), 14.0)
        )

    train_workers = max(1, int(os.environ.get("PUBG_RANKER_TRAIN_WORKERS", "4")))
    if train_workers == 1:
        vectors = [sample_vector(row) for row in samples]
    else:
        with ThreadPoolExecutor(max_workers=min(train_workers, len(samples))) as pool:
            vectors = list(pool.map(sample_vector, samples))
    X = np.asarray(vectors, dtype=np.float32)
    y = np.asarray([row.label for row in samples], dtype=np.int32)
    groups = np.asarray([row.video_id for row in samples])
    weights = np.asarray([row.weight for row in samples], dtype=np.float32)

    factories = {
        "logistic_regression": lambda: Pipeline(
            [
                ("scale", StandardScaler()),
                ("model", LogisticRegression(max_iter=1000, class_weight="balanced")),
            ]
        ),
        "random_forest": lambda: RandomForestClassifier(
            n_estimators=300,
            max_depth=5,
            min_samples_leaf=2,
            class_weight="balanced",
            random_state=42,
            n_jobs=1,
        ),
    }

    def fit_model(model: Any, name: str, x: Any, target: Any, sample_weight: Any) -> None:
        if name == "logistic_regression":
            model.fit(x, target, model__sample_weight=sample_weight)
        else:
            model.fit(x, target, sample_weight=sample_weight)

    evaluations: dict[str, dict[str, Any]] = {}
    if len(set(groups)) >= 3:
        for name, factory in factories.items():
            oof_y: list[int] = []
            oof_p: list[float] = []
            for train_idx, test_idx in LeaveOneGroupOut().split(X, y, groups):
                if len(set(y[train_idx])) < 2:
                    continue
                fold = factory()
                fit_model(fold, name, X[train_idx], y[train_idx], weights[train_idx])
                oof_y.extend(int(v) for v in y[test_idx])
                oof_p.extend(float(v) for v in fold.predict_proba(X[test_idx])[:, 1])
            threshold, balanced, f1 = _best_threshold(oof_y, oof_p)
            evaluations[name] = {
                "threshold": threshold,
                "balanced_accuracy": balanced,
                "f1": f1,
                "samples": len(oof_y),
                "objective": balanced * 0.7 + f1 * 0.3,
            }
    model_name = max(
        evaluations,
        key=lambda name: float(evaluations[name]["objective"]),
        default="logistic_regression",
    )
    selected = evaluations.get(
        model_name,
        {"threshold": 0.5, "balanced_accuracy": None, "f1": None},
    )
    threshold = float(selected["threshold"])
    oof_balanced_accuracy = selected["balanced_accuracy"]
    model = factories[model_name]()
    fit_model(model, model_name, X, y, weights)
    artifact = {
        "artifact_version": 1,
        "feature_version": FEATURE_VERSION,
        "feature_names": FEATURE_NAMES,
        "model": model,
        "model_name": model_name,
        "threshold": threshold,
        "training_signature": signature,
        "trained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "samples": len(samples),
        "positive": positives,
        "negative": negatives,
        "groups": len(set(groups)),
        "oof_balanced_accuracy": oof_balanced_accuracy,
        "oof_f1": selected["f1"],
        "candidate_models": evaluations,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=output.parent, suffix=".joblib", delete=False) as handle:
        tmp_path = Path(handle.name)
    try:
        joblib.dump(artifact, tmp_path)
        os.replace(tmp_path, output)
        _MODEL_CACHE = None
    finally:
        tmp_path.unlink(missing_ok=True)
    report = {key: value for key, value in artifact.items() if key != "model"} | {
        "status": "trained",
        "path": str(output),
    }
    report_path = output.with_suffix(".json")
    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return report


def _load_artifact() -> dict | None:
    global _MODEL_CACHE
    from path_safe import is_file as path_is_file

    path = model_path()
    if not path_is_file(path):
        return None
    try:
        mtime_ns = path.stat().st_mtime_ns
    except OSError:
        return None
    if _MODEL_CACHE and _MODEL_CACHE[:2] == (str(path), mtime_ns):
        return _MODEL_CACHE[2]
    try:
        import joblib

        artifact = joblib.load(path)
    except Exception:
        return None
    if tuple(artifact.get("feature_names") or ()) != FEATURE_NAMES:
        return None
    validation = artifact.get("oof_balanced_accuracy")
    min_validation = float(os.environ.get("PUBG_RANKER_MIN_OOF_BALANCED_ACCURACY", "0.52"))
    if validation is None and os.environ.get("PUBG_RANKER_ALLOW_UNVALIDATED", "0") != "1":
        return None
    if validation is not None and float(validation) < min_validation:
        return None
    _MODEL_CACHE = (str(path), mtime_ns, artifact)
    return artifact


def predict_score(video_path: Path, start_sec: float, duration_sec: float = 14.0) -> float | None:
    artifact = _load_artifact()
    if artifact is None:
        return None
    features = extract_features(video_path, start_sec, duration_sec)
    probability = artifact["model"].predict_proba([feature_vector(features)])[0][1]
    return float(probability)


def predict_from_features(features: dict[str, float]) -> float | None:
    artifact = _load_artifact()
    if artifact is None:
        return None
    probability = artifact["model"].predict_proba([feature_vector(features)])[0][1]
    return float(probability)


def ranker_available() -> bool:
    return _load_artifact() is not None


def rank_peaks_with_model(
    video_path: Path,
    peaks: list[float],
    *,
    part_sec: float = 14.0,
    max_probes: int | None = None,
) -> tuple[list[float], str]:
    artifact = _load_artifact()
    if artifact is None or os.environ.get("PUBG_RANKER_ENABLED", "1") != "1":
        return list(peaks), "ranker_unavailable"
    if max_probes is not None:
        cap = int(max_probes)
    elif os.environ.get("PUBG_FULL_PEAK_SCAN", "1") == "1":
        # Probe every peak — do not silently keep only the first 16.
        raw = int(os.environ.get("PUBG_RANKER_MAX_PROBES", "0") or 0)
        cap = len(peaks) if raw <= 0 else raw
    else:
        cap = int(os.environ.get("PUBG_RANKER_MAX_PROBES", "16"))
    cap = min(len(peaks), max(1, cap)) if cap > 0 else len(peaks)
    selected_indices: list[int] = list(range(min(len(peaks), max(1, cap // 2))))
    selected_set = set(selected_indices)
    # Reserve half the budget for timeline diversity. Global audio rank alone
    # repeatedly omitted quieter fights from later VOD chapters.
    chunks: dict[int, list[int]] = {}
    for index in range(len(peaks)):
        if index in selected_set:
            continue
        chunk = int(float(peaks[index]) // 300.0)
        chunks.setdefault(chunk, []).append(index)
    # Round-robin gives each chapter several candidates instead of only one.
    # Lists preserve generator strength order within the chapter.
    while len(selected_indices) < cap and any(chunks.values()):
        for chunk in sorted(chunks):
            if not chunks[chunk]:
                continue
            index = chunks[chunk].pop(0)
            selected_indices.append(index)
            selected_set.add(index)
            if len(selected_indices) >= cap:
                break
    for index in range(len(peaks)):
        if len(selected_indices) >= cap:
            break
        if index not in selected_set:
            selected_indices.append(index)
            selected_set.add(index)

    def extract(index: int) -> tuple[int, float, dict[str, float] | None]:
        peak = float(peaks[index])
        start = max(0.0, peak - part_sec * 0.5)
        try:
            features = extract_features(video_path, start, part_sec)
        except Exception:
            features = None
        return index, peak, features

    workers = max(1, int(os.environ.get("PUBG_RANKER_WORKERS", "4")))
    if workers == 1 or len(selected_indices) < 2:
        extracted = [extract(index) for index in selected_indices]
    else:
        with ThreadPoolExecutor(max_workers=min(workers, len(selected_indices))) as pool:
            extracted = list(pool.map(extract, selected_indices))
    valid = [(index, peak, features) for index, peak, features in extracted if features is not None]
    probabilities = (
        artifact["model"].predict_proba(
            [feature_vector(features) for _index, _peak, features in valid]
        )[:, 1]
        if valid
        else []
    )
    probability_by_index = {
        index: float(probability)
        for (index, _peak, _features), probability in zip(valid, probabilities)
    }
    scored = [
        (probability_by_index.get(index, -1.0), index, peak)
        for index, peak, _features in extracted
    ]
    scored.sort(key=lambda row: (-row[0], row[1]))
    ranked = [peak for _score, _index, peak in scored]
    ranked.extend(float(peak) for index, peak in enumerate(peaks) if index not in selected_set)
    top = scored[0][0] if scored else -1.0
    return ranked, f"ranker top={top:.3f} n={len(scored)}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", action="store_true")
    parser.add_argument("--train-if-changed", action="store_true")
    parser.add_argument(
        "--dataset",
        type=Path,
        default=None,
        help="Train from exported JSONL (pubg_ranker_dataset export)",
    )
    args = parser.parse_args()
    if not args.train and not args.train_if_changed:
        parser.error("choose --train or --train-if-changed")
    report = train(if_changed=args.train_if_changed, dataset=args.dataset)
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return 0 if report["status"] in {"trained", "unchanged"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
